public class AdditionTwoInteger{

   static int a = 10;
   static int b = 20;

   public static void printAddition(){
       System.out.println(a + b);
   }

    public static void main(String args[]){
       printAddition();
    }

}
