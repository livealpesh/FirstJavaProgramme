public class IfElsePractice

{
static int number = 35;

    public static void main(String[] args)
    {
        if (number>=35)
        {
            System.out.println("\tyou are paas with\t" + number + "\tMarks");
        }else
        {
            System.out.println("\tyou are not paas with\t" + number + "\tMarks");
        }
    }
}
